<?php

return array(
	'Model Name'=>'Modellbezeichnung',
	'Lable field name'=>'Lable Feldnamen',
	'Empty item name'=>'Empty Artikelnamen',
	'Profile model relation name'=>'Profil Modell Verhältnis Namen',
);
