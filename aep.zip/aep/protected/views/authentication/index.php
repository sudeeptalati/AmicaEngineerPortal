<html>
<body>
<form action="index.php?r=authentication/authentication" method="post">
E-mail: <input type="text" name="email">
<br><br>
Password: <input type="text" name="pwd"><br>
<br>
<input type="submit">
</form>
</body>
</html>
