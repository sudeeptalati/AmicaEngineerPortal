<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>
